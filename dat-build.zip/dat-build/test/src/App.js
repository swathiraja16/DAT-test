import React, { Component } from 'react';
import './App.css';
import Home from './Components/HomeComponent'
import Signup from './Components/SignupComponent';
import Login from './Components/LoginComponent';
import { BrowserRouter, Route } from "react-router-dom";


class App extends Component {  

  Login = () => {
    return(
      <Login />
    )    
  }

  Home = () => {
    return(
      <Home />
    )    
  }

  Signup = () => {
    return(
      <Signup />
    )    
  }

  render() {
    return (
      <div className="App">
        <BrowserRouter>
          <div>
            <Route exact path="/" component={Home} />
            <Route exact path="/login" component={Login} />
            <Route exact path="/signup" component={Signup} />            
          </div>
        </BrowserRouter>
      </div>
    );
  }
}

export default App;
