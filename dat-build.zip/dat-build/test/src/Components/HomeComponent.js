import React, { Component } from 'react'; 

class Home extends Component {
    
    render(){
        return( 
            <div className="row">
                <div className="homebg">
                    <div className="col-12" style={{}}>
                        <a style={{color: 'white', position: "absolute", top: 32, right: 80, fontWeight: 'bold'}} href='/login'>Login</a>
                    </div>
                    <div className="row">
                        <img src="assets/images/gpc_logo_large@2x.png" alt="logo" style={{marginTop: 200, marginLeft: 486, marginRight: 485,width: 600}} />
                    </div>
                    <div className="row">
                        <h3 className="centered" style={{color:"white", marginTop: 42, marginBottom: 230}}>APP DESIGN & DEVELOPMENT AGENCY</h3>
                    </div>
                </div>

                {/*To display about part */}  

                <div className="container">
                    <div className="row">
                        <div className="col-4">
                            <h2 style={{ textAlign: "right", marginTop: 50, color: "#0E5C89"}}>WHO WE ARE</h2>
                        </div>
                        <div className="col-8">
                            <p style={{marginLeft: 160, marginTop: 50}}>D & A Technologies is a NYC-based app development firm that works with
                                Fortune 500 brands, leading retailers, funded startups and more to craft digital products and strategies that solve 
                                business problems and drive measurable results.
                            </p>
                            <p style={{marginLeft: 160}}> 
                                We're part of your team. That means working together to meet the business challenges you face. From iOS and Andriod 
                                to emerging technologies like VR, AR and wearables, we do whatever it takes to help you thrive in today's and 
                                tommorow's - digital ecosystem.
                            </p>
                        </div>                        
                    </div> 
                </div>

                {/*To display apps list part*/}

                <div className="appbg">
                    <div className="row">
                        <div className="col-12">
                            <h2 style={{marginTop: 80, textAlign: "center", color: "white"}}>OUR APPS</h2>
                        </div>
                    </div>
                    <div className="row" style={{marginTop: 64}}>
                        <div className="col-2" style={{marginLeft: 150}}>
                            <div className="row">
                                <a href="https://movo.me"><img src="assets/images/logo_movo@2x.png" width="175" alt="movo"/></a>
                            </div>
                            <br/>
                            <div className="row">
                                <a href="https://movo.me"><h5 style={{color: "white", marginLeft: 55}}>Movo</h5></a>
                            </div>
                            
                        </div>
                        <div className="col-2" style={{marginLeft: 81}}>
                            <div className="row">
                                <a href="https://itunes.apple.com/us/app/ww-body-analysis-scale-tracker/id1157071126?mt=?"><img src="assets/images/logo_conair@2x.png" width="175" alt="conair"/></a>
                            </div>
                            <br/>
                            <div className="row">
                                <a href="https://itunes.apple.com/us/app/ww-body-analysis-scale-tracker/id1157071126?mt=?"><h5 style={{color: "white", marginLeft: 55}}>Connair</h5></a>
                            </div>
                        </div>
                        <div className="col-2" style={{marginLeft: 81}}>
                            <div className="row">
                                <a href="https://itunes.apple.com/us/app/the-tapping-solution/id1419815487?mt=8"><img src="assets/images/logo_tappingSolution@2x.png" width="175" alt="tapping solution"/></a>
                            </div>
                            <br/>
                            <div className="row">
                                <a href="https://itunes.apple.com/us/app/the-tapping-solution/id1419815487?mt=8"><h5 style={{color: "white", marginLeft: 10}}>Tapping Solution</h5> </a>
                            </div>
                        </div>
                        <div className="col-2" style={{marginLeft: 81}}>
                            <div className="row">
                                <a href="https://www.gotenna.com"><img src="assets/images/logo_goTenna@2x.png" width="175" alt="goTenna"/></a>
                            </div>
                            <br/>
                            <div className="row">
                                <a href="https://www.gotenna.com"><h5 style={{color: "white", marginLeft: 55}}>goTenna</h5></a>
                            </div>
                        </div>
                    </div>                 
                </div>

                {/*Displays subscribe part*/}   
                <div className="container" style={{marginTop: 88}}>
                    <div className="row">
                        <div className="col-12">
                            <h2 style={{color: "#0E5C89", textAlign: "center"}}>SUBSCRIBE TO NEWSLETTER</h2>
                        </div>
                        <div className="col-12" style={{marginTop: 45}}>
                            <form action="http://dev.datechnologies.co/Tests/scripts/add-email.php" method='post' >
                                <center><input type="text" name="email" placeholder="Your email" style={{height: 49, width: 276, textAlign: 20}} onChange={this.handleChange}  />
                                <input type="submit" style={{height: 49, width: 165, backgroundColor: "#0E5C89", border: "none", color: "white"}} value="SUBSCRIBE" />
                                </center>
                            </form>
                        </div>
                    </div>
                </div>

                {/*Footer */}
                <div className="footer">
                    <p style={{marginLeft: 696, marginTop: 29}}>Footer</p>
                </div>
            </div>     
        );
    }      
}

export default Home;