import React, { Component } from 'react'; 
import {Button} from 'react-bootstrap';

class Signup extends Component{

    render() {
        return(
            <div className="loginbg">
                <a href='/'><img src="assets/images/gpc_logo@2x.png" alt="home" style={{marginLeft: 80, marginTop: 32}}/></a>
                <div className="centered">
                    <div className="row">
                        <div className="row middle-xs center-xs"> 
                            <center>
                                    <Button bsStyle="link" style={{color: "white"}} href="/signup"><h3>Sign Up</h3> </Button>{' '}
                                    <Button bsStyle="link" style={{color: "white", opacity: 0.6}} href="/login"><h3>Login</h3> </Button>{' '}
                            </center>
                        </div>
                    </div>
                    <form action="http://dev.datechnologies.co/Tests/scripts/user-signup.php" method="post">
                        <div className="row username" style={{marginTop: 30}}>
                                <input className="input" name= "username" type="text" placeholder="Username"></input>
                        </div>
                        <div className="row email" style={{marginTop: 12}}>
                            <input className="input" name="email" type="email" placeholder="test@datechnologies.co"></input>
                        </div>
                        <div className="row password" style={{marginTop: 12}}>
                            <input className="input" name="password" type="password" placeholder="Password"></input>
                        </div>
                        <div className="row" style={{marginTop: 32}}>
                            <input type="submit" className="loginbutton" value="SIGN UP" />
                    </div>   
                    </form>  
                </div>
            </div>
        );
    }
}

export default Signup;