import React, { Component } from 'react'; 
import {Button} from 'react-bootstrap';

class Login extends Component{  
    
    render() {
        
        return(
            <div className="loginbg">
                <a href='/'><img src="assets/images/gpc_logo@2x.png" alt="home" style={{marginLeft: 80, marginTop: 32}}/></a>
                <div className="centered">
                    <div className="row">
                        <div className="row middle-xs center-xs"> 
                            <center>
                                <Button bsStyle="link" style={{color: "white", opacity: 0.6}} href='/signup'><h3>Sign Up</h3> </Button>{' '}
                                <Button bsStyle="link" style={{color: "white"}} href="/login"><h3>Login</h3> </Button>{' '}
                            </center>
                        </div>
                    </div>
                    <form action="http://dev.datechnologies.co/Tests/scripts/user-login.php" method="post">
                        <div className="row email"  style={{marginTop: 30}} >
                            <input  type="email" name="email" placeholder="test@datechnologies.co" className="input"></input>
                        </div>
                        <div className="row password" style={{marginTop: 12}}>
                            <input  type="password" name="password" placeholder="Password" className="input"></input>
                        </div>
                        <div className="row" style={{marginTop: 32}}>
                            <button type="submit" className="loginbutton">LOGIN</button>
                        </div>     
                    </form>
                </div>
            </div>
        );
    }
}

export default Login;